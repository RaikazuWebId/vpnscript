from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/messiey/rocky/master/statushariini"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("SSH MENU", "ssh")],
                    [Button.inline("VMESS MENU", "vmess-member"),
                     Button.inline("VLESS MENU", "vless-member")],
                    [Button.inline("TROJAN MENU", "trojan-member"),
                     Button.inline("SHODOSOCK MENU", "shadowsocks-member")],
                    [Button.inline("NOOBVPN MENU", "noobzvpn-member")],
                    [Button.url("GRUP TELE RZ", "https://t.me/RAIKAZUVPN"),
                     Button.inline("TOPUP MANUAL", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━**
    `•VIP MEMBER PANEL•`
**━━━━━━━━━━━━━━━━**
**Notice:{response.text}**
**━━━━━━━━━━━━━━━━**
**  ➢SERVICE STATUS **
**» ssh status      :** `{get_ssh_status()}`
**» ssh xray        :** `{get_xray_status()}`
**» udp status      :** `{get_udp_status()}`
**» Noobzvpns status:** `{get_noobz_status()}`
**» slowdns status  :** `{get_slowdns_status()}`
**» dropbear status :** `{get_dropbear_status()}`
**» websocket status:** `{get_ws_status()}`
**» Anti DDoS status:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━**
**» VERSION:** `VIP VERSION`
**» GRUP RAIKAZU:** `@RAIKAZUVPN`
**» BOT BY @RAIKAZUSTORE **
**» ID KAMU ** `{user_id}`
**» HARGA SSH    IDR.10.000 **
**» HARGA VMESS  IDR.10.000 **
**» HARGA VLESS  IDR.10.000 **
**» HARGA TROJAN IDR.10.000 **
**» SISA SALDO MU: ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("SSH MENU", "ssh")],
                    [Button.inline("VMESS MENU", "vmess"),
                     Button.inline("VLESS MENU", "vless")],
                    [Button.inline("TROJAN MENU", "trojan"),
                     Button.inline("SOCKS MENU", "shadowsocks")],
                    [Button.inline("NOOBZ MENU", "noobzvpns"),
                     Button.inline("ACC MEMBER", "registrasi-member"),
                     Button.inline("HAPUS MEMBER", "delete-member")],
                     [Button.inline("LIST MEMBER", "show-user")],
                    [Button.inline("ADD SALDO MEMBER", "addsaldo")],
                    [Button.inline("CEK STATUS VPS", "info"),
                     Button.inline("MENU SETTING", "setting")],
                    [Button.url("GRUP RZ", "https://t.me/RAIKAZUVPN"),
                     Button.url("ORDER AUTOSC?", "https://t.me/RAIKAZUSTORE")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━**
  `•ADMIN PANEL MENU•`
**━━━━━━━━━━━━━━━━**
**Notice:{response.text}**
**━━━━━━━━━━━━━━━━**
**  ➢SERVICE STATUS **
**» ssh status      :** `{get_ssh_status()}`
**» ssh xray        :** `{get_xray_status()}`
**» udp status      :** `{get_udp_status()}`
**» Noobzvpns status:** `{get_noobz_status()}`
**» slowdns status  :** `{get_slowdns_status()}`
**» dropbear status :** `{get_dropbear_status()}`
**» websocket status:** `{get_ws_status()}`
**» Anti DDoS status:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━**
**» VERSION:** `VIP VERSION`
**» GRUP RZ:** `@RAIKAZUVPN`
**» BOT BY :** `@RAIKAZUSTORE`
**» ID KAMU ** `{user_id}`
**» HARGA SSH    IDR.10.000 **
**» HARGA UDP    IDR.10.000 **
**» HARGA NOOBZ  IDR.10.000 **
**» HARGA VMESS  IDR.10.000 **
**» HARGA VLESS  IDR.10.000 **
**» HARGA TROJAN IDR.10.000 **
**» TOTAL USER:** `{get_user_count()}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

